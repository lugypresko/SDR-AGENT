/*
  Warnings:

  - You are about to drop the column `planningStyle` on the `trip_plan` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "trip_plan" DROP COLUMN "planningStyle";
