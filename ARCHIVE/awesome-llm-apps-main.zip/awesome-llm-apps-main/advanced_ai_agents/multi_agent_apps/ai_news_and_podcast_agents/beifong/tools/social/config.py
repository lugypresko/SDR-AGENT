from db.config import get_browser_session_path

USER_DATA_DIR = get_browser_session_path()
